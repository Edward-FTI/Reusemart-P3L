<button class="btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions"
    aria-controls="offcanvasWithBothOptions">
    <img src="https://img.icons8.com/?size=100&id=8113&format=png&color=FFFFFF" alt="" width="30" height="24"
        class="d-inline-block align-text-top">
</button>

<div class="offcanvas offcanvas-start bg-success" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions"
    aria-labelledby="offcanvasWithBothOptionsLabel">
    <div class="offcanvas-header">
        <div class="d-flex align-items-center fw-bold fs-5 text-white">
            <img src="<?php echo e('asset/logo.png'); ?>" alt="" width="50" class="d-inline-block">
            Reusemart
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>

    <div class="offcanvas-body">
        
        <?php if (isset($component)) { $__componentOriginal1b4a9e465e0d44fd582a4af0f75fd0cc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b4a9e465e0d44fd582a4af0f75fd0cc = $attributes; } ?>
<?php $component = App\View\Components\LinkSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('link-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LinkSidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b4a9e465e0d44fd582a4af0f75fd0cc)): ?>
<?php $attributes = $__attributesOriginal1b4a9e465e0d44fd582a4af0f75fd0cc; ?>
<?php unset($__attributesOriginal1b4a9e465e0d44fd582a4af0f75fd0cc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b4a9e465e0d44fd582a4af0f75fd0cc)): ?>
<?php $component = $__componentOriginal1b4a9e465e0d44fd582a4af0f75fd0cc; ?>
<?php unset($__componentOriginal1b4a9e465e0d44fd582a4af0f75fd0cc); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\LENOVO\OneDrive\Desktop\P3L\Reusemart\resources\views/components/sidebar.blade.php ENDPATH**/ ?>