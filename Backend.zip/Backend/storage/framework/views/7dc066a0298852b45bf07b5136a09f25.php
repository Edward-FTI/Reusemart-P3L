<div class="d-flex flex-column gap-3">
    <a href="" class="d-flex align-items-center gap-2 text-white">
        <img src="https://img.icons8.com/?size=100&id=iPqKoSmxmAyJ&format=png&color=000000" alt="" width="30"
            class="d-inline-block">
        Dashboard
    </a>
    <a href="" class="d-flex align-items-center gap-2 text-white">
        <img src="https://img.icons8.com/?size=100&id=13042&format=png&color=000000" alt="" width="30"
            class="d-inline-block">
        Data Pegawai
    </a>
    <a href="" class="d-flex align-items-center gap-2 text-white">
        <img src="https://img.icons8.com/?size=100&id=13042&format=png&color=000000" alt="" width="30"
            class="d-inline-block">
        Data User
    </a>
    <a href="" class="d-flex align-items-center gap-2 text-white">
        <img src="https://img.icons8.com/?size=100&id=aurymxpl98YH&format=png&color=000000" alt=""
            width="30" class="d-inline-block">
        Data Role
    </a>
    <a href="" class="d-flex align-items-center gap-2 text-white">
        <img src="https://img.icons8.com/?size=100&id=hSUoULMc0FvV&format=png&color=000000" alt=""
            width="30" class="d-inline-block">
        Data Barang
    </a>
</div>
<?php /**PATH C:\Users\LENOVO\OneDrive\Desktop\P3L\Reusemart\resources\views/components/link-sidebar.blade.php ENDPATH**/ ?>