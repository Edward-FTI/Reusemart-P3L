<x-layout>

{{-- Konten Disini --}}

</x-layout>